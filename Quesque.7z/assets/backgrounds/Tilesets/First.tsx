<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="2019.04.25" name="First" tilewidth="8" tileheight="8" tilecount="2400" columns="48">
 <image source="First.png" width="384" height="400"/>
 <tile id="4" probability="0.25"/>
 <tile id="5" probability="0.25"/>
 <tile id="6" probability="3"/>
 <tile id="52" probability="0.25"/>
 <tile id="53" probability="0.25"/>
 <tile id="100" probability="0.2"/>
 <tile id="101" probability="0.2"/>
 <tile id="148" probability="0.2"/>
 <tile id="149" probability="0.2"/>
 <tile id="152" probability="7"/>
 <tile id="153" probability="3"/>
 <tile id="197" probability="10"/>
 <tile id="198" probability="10"/>
 <tile id="772" probability="3"/>
</tileset>
